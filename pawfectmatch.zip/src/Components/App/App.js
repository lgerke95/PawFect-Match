import './App.css';
import { useState, useEffect } from 'react';

import searchTheDogApi from '../../Utils/TheDogApi';
import searchPetFinder from '../../Utils/PetFinder';

import SearchBar from '../SearchBar/SearchBar';
import DogList from '../DogList/DogList';

function App() {
  const [dogCards, setDogCard] = useState([]);
  const [breedFacts, setBreedFacts] = useState({});
  const [breeds, setBreeds] = useState([]);

  const search = async (term, age, size, breed) => {
    const searchResults = await searchPetFinder(term, age, size, breed);



    const dogsWithPhotos = searchResults.filter(dog =>
        dog.photos &&
        dog.photos.length > 0 &&
        dog.photos[0] &&
        typeof dog.photos[0].medium === 'string' &&
        dog.photos[0].medium !== "https://placedog.net/500" &&
        dog.description &&
        dog.description.trim().split(' ').length >= 5
      );
      
      

      
      
    
    const uniqueDogs = [];
    const seenIds = new Set();
    
    for (const dog of dogsWithPhotos) {
      if (!seenIds.has(dog.id)) {
        uniqueDogs.push(dog);
        seenIds.add(dog.id);
      }
    }

    const facts = {};
    for (const dog of uniqueDogs) {
      if (dog.breeds?.primary && !facts[dog.breeds.primary]) {
        facts[dog.breeds.primary] = await searchTheDogApi(dog.breeds.primary);
      }
    }

    setDogCard(uniqueDogs);
    setBreedFacts(facts);
  };

  useEffect(() => {
    search("", "", "", "");  
  }, []); 

  return (
    <main>
      <SearchBar search={search} breeds={breeds} />
      <DogList dogCards={dogCards} breedFacts={breedFacts} />
    </main>
  );
}

export default App;
